#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: kkearney
"""
# Used for organizing files and adjusting file names
from datetime import datetime
import os
import shutil
import re

# OpenSim
import opensim as osim

# Data handling and some math
import pandas as pd
import numpy as np
import joblib
import math
from scipy.interpolate import interp1d
import random

# Figures
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns

# Machine learning
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.model_selection import RandomizedSearchCV
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.multioutput import MultiOutputRegressor
#%% mkoutdir
def mkoutdir(path, usedate=False):
    # Include date in output directory name if usedate ==True
    if usedate == True:
        now = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        date = now.split(sep='/')[0]+now.split(sep='/')[1]
        outdir = path + '_' + date
    else:
        outdir = path
    
    # If directory does not exist, make it
    if os.path.exists(outdir) == False:
        os.mkdir(outdir)
        note = 'Directory created: ' + outdir
    else:
        note = 'Directory already exists'
    print(note)
    return outdir

#%% addcoordacts
def addcoordacts(forcedf, model, newmodel, minControl = -1, maxControl = 1):
    for index,row in forcedf.iterrows():
        coordName = row['Actuator']
        optForce = row['Optimal Force']
        
        coordSet = model.updCoordinateSet()
        actu = osim.CoordinateActuator()
        actu.setName(coordName)
        actu.setCoordinate(coordSet.get(coordName))
        actu.setOptimalForce(optForce)
        actu.setMinControl(minControl)
        actu.setMaxControl(maxControl)
        model.addComponent(actu)
    
    # Save the model with new actuators
    model.printToXML(newmodel + '.osim') 
    
    return model

#%% strip
def strip(text):
    try:
        return text.strip()
    except AttributeError:
        return text

#%% parsebounds
def parsebounds(filename, model):
    header = pd.read_csv(filename, sep = '\t', nrows = 1, header = None)
    bounds = pd.read_csv(filename, skiprows=1, sep = '\t',
                         converters = {'Name' : strip})
   
   
    # If true, the bounds are in degrees and must be converted to radians
    if 'yes' in header[1].values:
        coordinate_set = model.getCoordinateSet()
        currLB = []
        currUB = []
        currIV = []
        currFV = []
       
        for index, row in bounds.iterrows():
            state = row['Name']
            coord = re.split('/', state)[-2]
           
            motion_type = coordinate_set.get(coord).getMotionType()
           
            # motion_type =1 is rotational
            if motion_type == 1 or motion_type==3:
                #print('motion_type = {}'.format(motion_type))
                currLB.append(float(row['LowerBound'])*math.pi/180)
                currUB.append(float(row['UpperBound'])*math.pi/180)
                currIV.append(float(row['InitialValue'])*math.pi/180)
                currFV.append(float(row['FinalValue'])*math.pi/180)
            elif motion_type == 2:
                #print('motion_type = {}'.format(motion_type))
                currLB.append(row['LowerBound'])
                currUB.append(row['UpperBound'])
                currIV.append(row['InitialValue'])
                currFV.append(row['FinalValue'])

        newbounds = pd.DataFrame({'Name' : bounds['Name'],
                                  'LowerBound' : currLB,
                                  'UpperBound' : currUB,
                                  'InitialValue' : currIV,
                                  'FinalValue' : currFV})
    else:
        newbounds = bounds
       
    return newbounds

#%% parseboundsUE
def parseboundsUE(filename, model):
    header = pd.read_csv(filename, sep = '\t', nrows = 1, header = None)
    bounds = pd.read_csv(filename, skiprows=1, sep = '\t',
                         converters = {'Name' : strip})
   
   
    # If true, the bounds are in degrees and must be converted to radians
    if 'yes' in header[1].values:
        coordinate_set = model.getCoordinateSet()
        currLB = []
        currUB = []
        currIV = []
        
       
        for index, row in bounds.iterrows():
            state = row['Name']
            coord = re.split('/', state)[-2]
           
            motion_type = coordinate_set.get(coord).getMotionType()
           
            # motion_type =1 is rotational
            if motion_type == 1 or motion_type==3:
                #print('motion_type = {}'.format(motion_type))
                currLB.append(float(row['LowerBound'])*math.pi/180)
                currUB.append(float(row['UpperBound'])*math.pi/180)
                currIV.append(float(row['InitialValue'])*math.pi/180)

            elif motion_type == 2:
                #print('motion_type = {}'.format(motion_type))
                currLB.append(row['LowerBound'])
                currUB.append(row['UpperBound'])
                currIV.append(row['InitialValue'])


        newbounds = pd.DataFrame({'Name' : bounds['Name'],
                                  'LowerBound' : currLB,
                                  'UpperBound' : currUB,
                                  'InitialValue' : currIV})

    else:
        newbounds = bounds
       
    return newbounds
#%% defstudy

def defstudy(model, bounds, bounds_noFV, t0, allgoals, tf, tfhigh = []):
    # Create the moco study
    study = osim.MocoStudy()
    
    # Initialize the problem and set the model.
    problem = study.updProblem()
    model.initSystem()
    problem.setModel(model)
    
    # Set the appropriate bounds for each state
    for index, row in bounds.iterrows():
        name = row['Name']
        
        if name in bounds_noFV:        
            LB = row['LowerBound']
            UB = row['UpperBound']
            IV = row['InitialValue']            
            problem.setStateInfo(name, [LB, UB], IV)
        else:
            LB = row['LowerBound']
            UB = row['UpperBound']
            IV = row['InitialValue']
            FV = row['FinalValue']
            problem.setStateInfo(name, [LB, UB], IV, FV)
            
    # Set bound of time over which to complete task
    if tfhigh:
        problem.setTimeBounds(osim.MocoInitialBounds(t0),osim.MocoFinalBounds(tf, tfhigh))
    else:
        problem.setTimeBounds(t0,tf)
    
    # Add goals
    for goal in allgoals:
        problem.addGoal(goal)
    
    return study

#%% defsolver
def defsolver(study, path, guess = [], nmesh = 50, verb = 2, optim = 'ipopt', cores = 6, conv_tol = 1e-4, const_tol = 1e-4, maxiter = 3000):
    solver = study.initCasADiSolver()
    solver.set_num_mesh_intervals(nmesh)
    solver.set_verbosity(verb)
    solver.set_optim_solver(optim)
    solver.set_parallel(cores)
    solver.set_optim_convergence_tolerance(conv_tol)
    solver.set_optim_constraint_tolerance(const_tol)
    solver.set_optim_max_iterations(maxiter)
    solver.set_transcription_scheme('hermite-simpson')
    #solver.set_output_interval(out_int)
    if guess == 'Random':
        guess = solver.createGuess()
        guess.randomizeAdd()
        guess.write(path + '/RandomGuess.mot')
        print('Random guess created. See RandomGuess.mot')
        solver.setGuess(guess)
    elif not guess:
        print('No guess provided')
    else: 
        solver.setGuessFile(guess)
        print('Guess file: ' + guess)
        
    return solver
#%% formatbounds
def formatbounds(model_init, model_final, boundsfile, speedbounds, indegrees = 'no'):
    LB = []
    UB = []
    IV = []
    FV = []
    Name = []
    
    # Provides LB, UB, and IV for each joint
    model = osim.Model(model_init)
    model.initSystem()
    state = model.initSystem()
    
    coordset = model.getCoordinateSet()
    iterator = coordset.SetIterator(coordset,0)
    for coord in iterator:        
        Name.append(coord.getAbsolutePathString()+'/value')
        ran = coord.getPropertyByName('range').toString().replace('(', '').replace(')','').split(' ')
        LB.append(float(ran[0]))
        UB.append(float(ran[1]))
        IV.append(coord.getValue(state))

        
    # Provides FV for each joint
    model = osim.Model(model_final)
    model.initSystem()
    state = model.initSystem()
    
    coordset = model.getCoordinateSet()
    iterator = coordset.SetIterator(coordset,0)
    for coord in iterator:       
        FV.append(coord.getValue(state))
            
    # Organize LB, UB, IV, and FV into dataframe. Check whether IV/FV within bounds. Write to new bounds file.
    newbounds = pd.DataFrame({'Name' : Name,
                              'LowerBound' : LB,
                              'UpperBound' : UB,
                              'InitialValue' : IV,
                              'FinalValue': FV})
                                
    # Check nothing is out of bounds
    for index,row in newbounds.iterrows():
        name = row['Name']
        lb = row['LowerBound']
        ub = row['UpperBound']
        iv = row['InitialValue']
        fv = row['FinalValue']
        if iv > ub or iv < lb:
            print('IV of {} out of bounds'.format(name))
        if fv>ub or fv<lb:
            print('FV of {} out of bounds'.format(name))
    
    indeg = pd.DataFrame(columns = ['indegrees', indegrees])
    indeg.to_csv(boundsfile, sep = '\t', index = False)
    newbounds.to_csv(boundsfile, sep = '\t', index = False, mode = 'a')
    
    speeds = pd.read_csv(speedbounds, sep = '\t')
    speeds.to_csv(boundsfile, sep = '\t', index = False, header = False, mode = 'a')
#%% formatguess
def formatguess(randfile, boundsfile, guessfile): 
    
    # Get header for guess file
    endheader = search_string_in_file(randfile, 'endheader')['line'][0]
    header = pd.read_csv(randfile, sep = '\t', nrows = endheader, header = None)
    header = header[0]
    
    
    oldguess = pd.read_csv(randfile, sep = '\t', skiprows = endheader)
    tsteps  = len(oldguess)

    # Use bounds file to get IVs and FVs 
    bounds = pd.read_csv(boundsfile, sep = '\t', skiprows = 1)

    # Build new guess iteratively
    newguess = pd.DataFrame()
    for col in oldguess.columns:
        row = bounds.loc[bounds['Name'] == col]
        if row.empty==False:
            iv = row['InitialValue']
            fv = row['FinalValue'] 
            newguess[col] = np.linspace(float(iv.values[0]), float(fv.values[0]), tsteps)
        else: 
            newguess[col] = oldguess[col]
            print(col + ' not in bounds file')

    headerdf = pd.DataFrame(header)
    headerdf.to_csv(guessfile, sep = '\t', index = False, header = False)
    newguess.to_csv(guessfile, sep = '\t', index = False, mode = 'a')

#%% generateModels
def generateModels(outpath, modelname, xcoords, ycoords, statename):
    # Path to print files to 
    outpath = mkoutdir(outpath)
    
    # Define musculoskeletal model and state
    model = osim.Model(modelname)
    state = model.initSystem()
    
    # Iterate through default box locations to set box to
    i = 0
    
    check = 0 # Used to produce an error if model did not get set to coords correctly
    
    for tx in xcoords:
        for ty in ycoords:    
            
            # Set box location
            model.getCoordinateSet().get('Box_tx').setValue(state, tx)
            model.getCoordinateSet().get('Box_ty').setValue(state, ty)
    
            # Iterate through all coordinates. Get value for each coord for the box locations defined. Then, set these values as the default.
            allcoords = model.getCoordinateSet()
            iterator = allcoords.SetIterator(allcoords, 0)
            for item in iterator:
                currcoord = item.getName()
                currval= item.getValue(state)
                model.getCoordinateSet().get(currcoord).setDefaultValue(currval)
                
            # Set all coordinates not free to satisfy contraints
            allcoords = model.getCoordinateSet()
            iterator = allcoords.SetIterator(allcoords, 0)
            for item in iterator:
                currcoord = item.getName()
                model.getCoordinateSet().get(currcoord).set_is_free_to_satisfy_constraints(False)
                
                if statename == 'Initial':
                    outmodel = 'LiftModel_{}.osim'.format(i)
                    # Lock all box coords as needed for running init pose simulations
                    if 'Box' in currcoord:
                        model.getCoordinateSet().get(currcoord).setDefaultLocked(True)
                elif statename == 'Final':
                    outmodel = 'LiftModel_{}_final.osim'.format(i)
                else:
                    print('Please specify statename as Intial or Final')
                
            # Check that the default values set match the desired tx and ty
            xachieved = np.round(model.getCoordinateSet().get('Box_tx').getDefaultValue(),4)
            yachieved = np.round(model.getCoordinateSet().get('Box_ty').getDefaultValue(),4)
            if np.round(tx,4) != xachieved:
                print('Error! '+outmodel+' could not be set to Box x-coordinate defined. tx = {}'.format(tx))
                check = 1
                break
            if np.round(ty,4) != yachieved:
                print('Error! '+outmodel+' could not be set to Box y-coordinate defined. ty = {}'.format(i,ty))
                check = 1
                break
            
            # Print model to output directory
            model.printToXML(outpath+ '/' + outmodel)
            
            # Redefine and initialize model
            model = osim.Model(modelname)
            state = model.initSystem()
            
            i = i+1
    print('Models have been printed to {}'.format(outpath))

#%% generateBaselineFinModel
def generateBaselineFinModel(modelname):
    model = osim.Model(modelname)
    state = model.initSystem()
    
    # Enable box to satisfy constraints to adjust model posture as needed
    boxcoords = ['Box_tx', 'Box_ty']
    for coord in boxcoords:
        model.getCoordinateSet().get(coord).set_is_free_to_satisfy_constraints(True)
    model.getCoordinateSet().get('Box_ty').setValue(state, 1.45)
    model.getCoordinateSet().get('Box_tx').setValue(state, 0.75)
    
    # Set all non-UE coords = 0 and define this as the default state
    LEcoords = ['knee_angle_r', 'lumbar_extension', 'ankle_angle_r', 'hip_flexion_r']
    for coord in LEcoords:
        model.getCoordinateSet().get(coord).setValue(state, 0)
    
    allcoords = model.getCoordinateSet()
    iterator = allcoords.SetIterator(allcoords, 0)
    for item in iterator:
        currcoord = item.getName()
        currval= item.getValue(state)
        model.getCoordinateSet().get(currcoord).setDefaultValue(currval)
    
    # Make box satisfy constraints again
    model.getCoordinateSet().get('Box_ty').set_is_free_to_satisfy_constraints(False)
    model.getCoordinateSet().get('Box_tx').set_is_free_to_satisfy_constraints(False)
    
    # Save model.
    finalmodelname = re.split('.osim',modelname)[0] + '_Final.osim'
    model.printToXML(finalmodelname)
    
    print('Printed baseline final model to {}'.format(os.getcwd()))
    
    return finalmodelname

#%% generateFVs
def generateFVs(outpath, modelname, finalxcoords, finalycoords):
    # Path to print files to 
    outpath = mkoutdir(outpath)
    
    # Define musculoskeletal model and state
    model = osim.Model(modelname)
    state = model.initSystem()
    i = 0
    for tx in finalxcoords:
        for ty in finalycoords:              
            
            model.getCoordinateSet().get('Box_tx').setValue(state, tx)
            model.getCoordinateSet().get('Box_ty').setValue(state, ty)
                
            # Iterate through all coordinates. Get value for each coord for the box locations defined. Then, set these values as the default.
            allcoords = model.getCoordinateSet()
            iterator = allcoords.SetIterator(allcoords, 0)
            for item in iterator:
                currcoord = item.getName()
                currval= item.getValue(state)
                model.getCoordinateSet().get(currcoord).setDefaultValue(currval)
            
            
            # Set all coordinates not free to satisfy contraints
            allcoords = model.getCoordinateSet()
            iterator = allcoords.SetIterator(allcoords, 0)
            for item in iterator:
                currcoord = item.getName()
                model.getCoordinateSet().get(currcoord).set_is_free_to_satisfy_constraints(False)
        
            # Check that the default values set match the desired tx and ty
            if np.round(tx,4) != np.round(model.getCoordinateSet().get('Box_tx').getDefaultValue(),4):
                print('Error! LiftModel_{}_final.osim tx does not match coordinate set. Try changing box coordinates defined. tx = {}'.format(i,tx))
            if np.round(ty,4) != np.round(model.getCoordinateSet().get('Box_ty').getDefaultValue(),4):
                print('Error! LiftModel_{}_final.osim ty does not match coordinate set. Try changing box coordinates defined. ty = {}'.format(i,ty))
            
            model.printToXML(outpath+'/LiftModel_{}_final.osim'.format(i))
            
            # Redefine and initialize model
            model = osim.Model(modelname)
            state = model.initSystem()
            
            i=i+1
        
    print('Final models have been printed to {}'.format(outpath))

#%% trajpercplot
def trajpercplot(key, simfolder, savename):
    # Plot Angles over % Task Completion
    statesdf = pd.DataFrame()
    x_prime = np.linspace(0,100,101)
    for index,row in key.iterrows():
        simname = 'Sim_{}'.format(int(row['Sim Number']))
        simdir = simfolder + '/' + simname +'/'
        currsto = [x for x in os.listdir(simdir) if '.sto' in x]
        if len(currsto)!=1:
            print(simname + 'has no Moco output')
            break
        else:
            currsto = currsto[0]
        endheader = search_string_in_file(simdir+currsto, 'endheader')['line'][0]
        states = pd.read_csv(simdir+currsto, skiprows = endheader, sep = '\t')
        allcols = states.columns
        cols = ['time']+[x for x in allcols if 'value' in x]
        cols = [x for x in cols if 'Box' not in x]
        currdf = states[cols]
        
        interpdf = pd.DataFrame()
        x = ((currdf['time']-currdf['time'].iloc[0])/(currdf['time'].iloc[-1]-currdf['time'].iloc[0]))*100
        interpdf['% Task Completion'] = x_prime
        for col in cols[1::]:
            y = currdf[col]
            interpolator = interp1d(x, y, kind='linear')
            y_prime = interpolator(x_prime)
            interpdf[col] = y_prime
            
        statesdf = pd.concat([statesdf, interpdf])
    
    abbrevcols = ['% Task Completion'] + [re.split('/',x)[-2] for x in cols[1::]]
    statesdf.columns = abbrevcols
    statesdfform = pd.melt(statesdf, id_vars=['% Task Completion'], value_vars=abbrevcols[1::], value_name = 'Joint Angles (Radians)', var_name = 'Coordinate')
    
    fig = matplotlib.pyplot.gcf()
    fig.set_size_inches(12,6)
    sns.set_style("whitegrid")
    g = sns.lineplot(x="% Task Completion", y='Joint Angles (Radians)',
                 hue="Coordinate", data=statesdfform, ci='sd')
    plt.legend(bbox_to_anchor=(1.01, 1), loc=2, fontsize = 12)
    g.set(xlim=(0, 100))    
    g.tick_params(labelsize=12)
    g.set_xlabel('% Task Completion',fontsize=15)
    g.set_ylabel('Joint Angles (Radians)',fontsize=15)
    plt.savefig(savename,bbox_inches='tight', dpi = 600)
    plt.show()

#%% trajtimeplot
def trajtimeplot(simfolder, savename):
    statesdf = pd.DataFrame()
    x_prime = np.linspace(0,1,101)
    for sim in os.listdir(simfolder):
        simdir = simfolder+ '/'+ sim +'/'
        currsto = [x for x in os.listdir(simdir) if sim+'.sto' in x]
        if len(currsto)!=1:
            print(sim + ' has {} Moco outputs'.format(len(currsto)))
            pass
        else:
            currsto = currsto[0]
            endheader = search_string_in_file(simdir+currsto, 'endheader')['line'][0]
            states = pd.read_csv(simdir+currsto, skiprows = endheader, sep = '\t')
            allcols = states.columns
            cols = ['time']+[x for x in allcols if 'value' in x]
            cols = [x for x in cols if 'Box' not in x]
            currdf = states[cols]
            
            interpdf = pd.DataFrame()
            x = currdf['time']
            interpdf['time'] = x_prime
            for col in cols[1::]:
                y = currdf[col]
                interpolator = interp1d(x, y, kind='linear')
                y_prime = interpolator(x_prime)
                interpdf[col] = y_prime
                
            statesdf = pd.concat([statesdf, interpdf])
        
    abbrevcols = ['time'] + [re.split('/',x)[-2] for x in cols[1::]]
    statesdf.columns = abbrevcols
    statesdfform = pd.melt(statesdf, id_vars=['time'], value_vars=abbrevcols[1::], value_name = 'Joint Angles (Radians)', var_name = 'Coordinate')
    
    fig = matplotlib.pyplot.gcf()
    fig.set_size_inches(12,6)
    sns.set_style("whitegrid")
    g = sns.lineplot(x="time", y='Joint Angles (Radians)',
                 hue="Coordinate", data=statesdfform, ci='sd')
    plt.legend(bbox_to_anchor=(1.01, 1), loc=2, fontsize = 12)
    g.set(xlim=(0, 1))   
    g.tick_params(labelsize=12)
    g.set_xlabel('Time (s)',fontsize=15)
    g.set_ylabel('Joint Angles (radians)',fontsize=15)
    plt.savefig(savename,bbox_inches='tight', dpi = 600)
    
#%% objhist
def objhist(simfolder, savename):
    #Visualize objective across simulations
    objectives = pd.DataFrame()
    for index,row in key.iterrows():
        simname = 'Sim_{}'.format(int(row['Sim Number']))
        simdir = simfolder + '/'+simname +'/'
        currsto = [x for x in os.listdir(simdir) if '.sto' in x]
        if len(currsto)!=1:
            print(simname + 'has no Moco output')
            break
        else:
            currsto = currsto[0]
        
        header = pd.read_csv(simdir+currsto, nrows = 17, sep = '=', header = None)
        objectives = pd.concat([objectives, header[header[0].str.match('objective')]])
    
    objectives.columns = ['item', 'Objective']
    objectives['Objective'] = pd.to_numeric(objectives['Objective'])
    objectives = objectives.replace('objective_back_back_momz','JR goal(back moment-z)')
    objectives = objectives.replace('objective','Total')
    objectives = objectives.replace('objective_effort','Effort goal')
    ax = sns.violinplot(x="item", y="Objective", data=objectives)
    ax.set_xlabel('')
    
    plt.savefig(savename,bbox_inches='tight', dpi = 600)
    
#%% solverstats
def solverstats(logfile, savename, stat = 'obj', plotme = False, convonly = True):
    cols = ['a', 'b']
    log = pd.read_csv(logfile, names = cols)
    log = log[log['a'].str.contains('iter')==False].reset_index()
    locs= log[log['a'].str.contains('Number of Iterations....:')]
    if convonly == True:
        locs = locs[~locs.isin(['Number of Iterations....: 1000']).any(axis=1)]
    prevind = 0
    alldata = pd.DataFrame()
    xy = []
    j = 0
    for index,row in locs.iterrows():  
        newdata = pd.DataFrame()
        maxiters= int(re.split(': ',row['a'])[-1])
        if maxiters != 1000:
            print(index, row['a'])
            
        data = pd.DataFrame(log['a'].iloc[(index-maxiters):(index)])
        
        currsim = log.iloc[prevind:index]
        #simname = currsim[currsim['a'].str.contains('Sim_')]
        xinit = float(re.split(' ',currsim[currsim['a'].str.contains('/jointset/BoxGround/Box_tx/value')]['b'].values[0])[-1])
        yinit = float(re.split(' ',currsim[currsim['a'].str.contains('/jointset/BoxGround/Box_ty/value')]['b'].values[0])[-3])
        yfin = float(re.split(' ',currsim[currsim['a'].str.contains('/jointset/BoxGround/Box_ty/value')]['b'].values[0])[-1])
        #if simname[simname['a'].str.contains('final')==False]['a'].iloc[0] != simname[simname['a'].str.contains('final')==False]['a'].iloc[1]:
        #    print('There are two different sim names')
        #    break
        #simname = re.split('/',simname[simname['a'].str.contains('final')==False]['a'].iloc[0])[-1]
        prevind = index+1
        
        objective = []
        iteration = []
        constviolation = []
        infdu = []
        lg = []
        d = []
        lgrg = []
        alphadu =[]
        alphapr= []
        ls = []
        for index,row in data.iterrows():
            a = row['a']
            strlist = re.split(' ',a)
            newstr = [x for x in strlist if x]
            
            objective.append(float(newstr[1]))
            constviolation.append(float(newstr[2]))
            infdu.append(float(newstr[3]))
            lg.append(float(newstr[4]))
            d.append(float(newstr[5]))
            lgrg.append(newstr[6])
            alphadu.append(float(newstr[7]))
            ls.append(float(newstr[9]))
            

            numeric_filter = filter(str.isdigit, newstr[0])
            iteration.append(int("".join(numeric_filter)))
                
            numeric_filter = filter(str.isdigit, newstr[8])
            alphapr.append(float("".join(numeric_filter)))
                
        #newdata['model'] = [simname]*len(iteration)
        newdata['tx_init'] = xinit*np.ones(len(iteration))
        newdata['ty_init'] = yinit*np.ones(len(iteration))
        newdata['ty_fin'] = yfin*np.ones(len(iteration))
        newdata['iter'] = iteration
        newdata['obj'] = objective
        newdata['inf_pr'] = constviolation
        newdata['inf_du'] = infdu
        newdata['lg(mu)'] = lg
        newdata['||d||'] = d
        newdata['lg(rg)'] = lgrg
        newdata['alpha_du'] = alphadu
        newdata['alpha_pr'] = alphapr
        newdata['ls'] = ls
        
        alldata = pd.concat([alldata,newdata])
        if plotme == True:
            g = sns.lineplot(x="iter", y=stat, data= newdata)
            xy.append('init: ({}, {}) finy: {}'.format(str(xinit),str(yinit), str(yfin)))
            j = j+1
    
    if plotme == True:
        plt.legend(xy,bbox_to_anchor=(1.01, 1), loc=2, fontsize = 12)
        plt.tight_layout()
        plt.rcParams["figure.figsize"] = (12,12)
        plt.savefig(savename, dpi = 600)
    return alldata

#%% Box Positions
def trajboxplot(simfolder, savename, xname, yname, key, finaly):
    key = key.drop_duplicates(subset = 'Initial Box_tx')
    
    fig = matplotlib.pyplot.gcf()
    fig.set_size_inches(12,6)
    sns.set_style("whitegrid")
    
    allstates = pd.DataFrame()
    for sim in os.listdir(simfolder):
        print(sim)
        simdir = simfolder+ '/'+ sim +'/'
        currsto = [x for x in os.listdir(simdir) if sim+'.sto' in x]
        if len(currsto)!=1:
            print(sim + ' has {} Moco outputs'.format(len(currsto)))
            pass
        else:
            currsto = currsto[0]
            endheader = search_string_in_file(simdir+currsto, 'endheader')['line'][0]
            states = pd.read_csv(simdir+currsto, skiprows = endheader, sep = '\t')
            allcols = states.columns
            cols = [x for x in allcols if 'value' in x]
            cols = ['time']+[x for x in cols if 'Box' in x]
            newstates = states[cols]
        
            abbrevcols = ['time'] + [re.split('/',x)[-2] for x in cols[1::]]
            
            newstates.columns = abbrevcols
            
            if np.round(newstates['Box_ty'].iloc[0],4) in key['Initial Box_ty'].values:
                if np.round(newstates['Box_ty'].iloc[-1],4) == np.round(finaly,4):
                    newstates['Simulation'] = [sim]*len(newstates)
                            #ax.scatter(newstates[xname], newstates[yname], newstates[zname])
                    allstates = pd.concat([allstates, newstates])
    sns.scatterplot(x=xname, y=yname, data=allstates, hue = 'Simulation')
    plt.pause(1)

    plt.legend(bbox_to_anchor=(1.01, 1), loc=2, fontsize = 12)
    plt.savefig(savename,bbox_inches='tight', dpi = 600)
#%% initInformedIVs
def initInformedIVs(modeldir, modelname, initsimpath, initsimkey = []):
    # Path to print files to 
    outpath = mkoutdir(modeldir)

    # Define musculoskeletal model and state
    model = osim.Model(modelname)
    state = model.initSystem()

    # Used to generate key
    allsims = []
    allmodels = []
    x = []
    y = []

    if initsimkey:
        key = generateKey(initsimpath)
        key['OutModel'] = ''

    i = 0
    for path, subdirs, files in os.walk(initsimpath):
        if path == initsimpath:
            pass
        else:
            currsto = [f for f in files if '.sto' in f]
            if len(currsto) !=1:
                print(path + ' has {} sto files'.format(len(currsto)))
            else:
                endheader = search_string_in_file(os.path.join(path,currsto[0]), 'endheader')['line'][0]
                currstate = pd.read_csv(os.path.join(path,currsto[0]), sep = '\t', skiprows = endheader)
                coordcols = [c for c in currstate.columns if 'value' in c]
                currcoords = currstate[coordcols]
                currcoords.columns = [re.split('/',x)[-2] for x in currcoords.columns] # Abbreviated columns to match coord names directly
                initvals = currcoords.iloc[-1]

                # Iterate through all coordinates. Set initvalues as the default. Also, set not free to satisfy constraints
                allcoords = model.getCoordinateSet()
                iterator = allcoords.SetIterator(allcoords, 0)
                for item in iterator:
                    modelcoord = item.getName()
                    model.getCoordinateSet().get(modelcoord).setDefaultValue(initvals[modelcoord])
                    model.getCoordinateSet().get(modelcoord).set_is_free_to_satisfy_constraints(False)

                # Print model to output directory
                model.printToXML(outpath+ '/LiftModel_{}.osim'.format(i))


                # Check that model coord defaults are set as intended
                allcoords = model.getCoordinateSet()
                iterator = allcoords.SetIterator(allcoords, 0)
                for item in iterator:
                    modelcoord = item.getName()
                    currvalue = item.getDefaultValue()
                    if currvalue != initvals[modelcoord]:  
                        print('Error! Coord {} on LiftModel_{}.osim has incorrect init value'.format(modelcoord,i))

                if initsimkey:
                    key.loc[key['Simulation'].str.contains(path),'OutModel'] = outpath+ '/LiftModel_{}.osim'.format(i)


                # Redefine and initialize model
                model = osim.Model(modelname)
                state = model.initSystem()

                i = i+1
    if initsimkey:
        # Check that the 'OutModel' column was filled in 
        if not key[key['OutModel']==''].empty:
            print('Error! Model associated with simulation was not stored to key. Therefore, key was not written.')
        else:
            key.to_csv(initsimkey,sep = '\t', index = False)
    print('Key printed to' + initsimkey)
    print('Models have been printed to {}'.format(outpath))
    
#%% genRandomWeights
def genRandomWeights(ngoals, nsims):
    weights = []
    for i in range(nsims):
        randvals = np.random.uniform(0, 1, ngoals)
        total = sum(randvals)
        weights.append(randvals/total)
       
    return weights

#%% initPoseSims
def initPoseSims(path, modeldir, speedbounds, randfile, simdir, weights, currweight, t0 = 0, tflow = 0.25, tfhigh = 1, maxiter = 1000, nmesh = 25, conv_tol = 1e-2, const_tol = 1e-2):
    # Directory to output sims to
    mkoutdir(simdir)
    
    # Get list of models to iterate through
    modelfiles = os.listdir(modeldir)
    
    # Record final and initial box values for key
    tyfin = []
    txinit = []
    tyinit = []
    simkey = [] 
    i = 0
    
    # List of coordinates for which no final value should be set. For determining inital pose, this is all of them
    model = osim.Model(modeldir + modelfiles[0])
    allcoords = model.getCoordinateSet()
    iterator = allcoords.SetIterator(allcoords, 0)
    bounds_noFV = []
    for item in iterator:
        bounds_noFV.append(item.getAbsolutePathString()+'/value')
    
    for modelfile in modelfiles:
        
        currmodel = modeldir + '/' + modelfile
        
        finalmodel = osim.Model(currmodel)
        
        model = osim.Model(currmodel)
        model.initSystem()
            
        
        simname = 'InitSim_w{}_{}'.format(currweight, i)
    
        # If output directory does not exist, make it
        outpath = simdir + simname
        outpath = mkoutdir(outpath, usedate=False)
        print(outpath)
        
        # Create bounds files
        boundsfile = outpath + '/'+ 'allbounds.txt'
        formatbounds(currmodel, currmodel, boundsfile, speedbounds)
        
        # Reads bounds file and converts degrees to radians if needed
        bounds = parsebounds(boundsfile, model) 
        
        # Define optimizer goals
        allgoals = []
    
        # MocoControlGoal: sum of the absolute value of the controls raised to a 
        # given exponent, integrated over the phase.
        effort_goal = osim.MocoControlGoal('effort')
        effort_goal.setDivideByDisplacement(True)
        effort_goal.setExponent(3)
        effort_goal.setWeight(weights[0])
        allgoals.append(effort_goal)
        
        # MocoJointReactionGoal: Minimize the sum of squares of specified reaction 
        # moment and force measures for a given joint, integrated over the phase. 
        joints = ['back', 'hip_r', 'knee_r','ankle_r']
        measure = ['moment-z']
        measuretag = 'momz' #Used in goal name (replaced the '-' ) 
        #joints = model.getJointSet().SetIterator(model.getJointSet(),0)
        k = 1
        for j in joints:
            rxn_goal = osim.MocoJointReactionGoal()
            rxn_goal.setName(j + '_' + measuretag)
            rxn_goal.setReactionMeasures(measure)
            rxn_goal.setJointPath('/jointset/'+j)
            rxn_goal.setWeight(measure[0], weights[k])
            allgoals.append(rxn_goal)
            k=k+1
        
        # Define the Moco study
        study = defstudy(model, bounds, bounds_noFV, t0, allgoals, tflow, tfhigh=tfhigh)
        
        # If random guess does not exist, create it. Then, format the linearly-interpolated guess and define solver    
        if os.path.exists(randfile) == True:
            guess = outpath + '/'+ 'Guess.mot'
            formatguess(randfile, boundsfile, guess)
            solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)
        else:
            print('Random guess did not exist. Creating now')
            guess = 'Random'
            
            #Just using to generate random guess file
            solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)
            
            # With random file generated, now format guess and redefine solver
            guess = outpath + '/'+ 'Guess.mot'
            formatguess(randfile, boundsfile, guess)
            solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)
        
        i = i+1
        
        
        # Solve and write the solution
        if not os.path.isfile('{}/{}.sto'.format(outpath,simname)):
            study.printToXML('{}/{}_study.xml'.format(outpath,simname))
            solution = study.solve()
            try:
                solution.write('{}/{}.sto'.format(outpath,simname))
            except: 
                solution.unseal().write('{}/{}_notconverged.sto'.format(outpath,simname))
        else:
            print('Simulation already exists. Please rename, move, or delete simulation.')
            
#%% search_string_in_file
# This function was posted to https://thispointer.com/python-search-strings-in-a-file-and-get-line-numbers-of-lines-containing-the-string/
# I only made minor edits
def search_string_in_file(file_name, string_to_search):
    """Search for the given string in file and return lines containing that string,
    along with line numbers"""
    line_number = 0
    list_of_results = []
    # Open the file in read only mode
    with open(file_name, 'r') as read_obj:
        # Read all lines in the file one by one
        for line in read_obj:
            # For each line, check if line contains the string
            line_number += 1
            if string_to_search in line:
                # If yes, then add the line number & line as a tuple in the list
                list_of_results.append((line_number, line.rstrip()))
    results = pd.DataFrame(list_of_results, columns=['line', 'string'])
    # Return list of tuples containing line numbers and lines where string is found
    return results.to_dict()

#%% generateKey
def generateKey(simdir):
    '''
    Inputs: 
        simdir = Path to simulation directory. This directory should only contain folders, each containing the Moco output and study defined for one simulation.
    Creates key by directly referencing study defined for Moco, as well as Moco output. This key combines the following info
    - Sim name (same name as labelled on the folder)
    - Whether the simulation converged
    - Initial x box position 
    - Initial y box position 
    - Final x box position 
    - Final y box position 
    - Final objectives reached
    - Solver duration (s)
    - Number of iterations
    - Study goals and their weights

    Note: This currently only works if the goals defined are 'effort' and/or joint reaction goals.
    '''

    simlist = []
    converged = []
    duration = []
    iterations = []
    xinit = []
    yinit = []
    xfin = []
    yfin = []
    objectives = pd.DataFrame() # Used df instead of list here since number of objectives and weights varies based on how solver is defined. 
    weights = pd.DataFrame()
    for sim in os.listdir(simdir):

        # Get output Moco file (.sto file)
        currsim = simdir + sim
        currsto = [f for f in os.listdir(currsim) if '.sto' in f]

        # If more or less than 1 sto file, something ain't right (simulation was probably never run, or ran multiple times with changing names)
        if len(currsto) !=1:
            print('Error: '+ sim + 'has {} sto files'.format(len(currsto)))
            break
        else:
            # Read output Moco states
            endheader = search_string_in_file(os.path.join(currsim,currsto[0]), 'endheader')['line'][0]
            currstate = pd.read_csv(os.path.join(currsim,currsto[0]), sep = '\t', skiprows = endheader)

            # Identify convergence, duration, number of iterations.
            success = re.split('=',search_string_in_file(os.path.join(currsim,currsto[0]), 'success')['string'][0])[-1]
            dur = re.split('=',search_string_in_file(os.path.join(currsim,currsto[0]), 'duration')['string'][0])[-1]
            it = re.split('=',search_string_in_file(os.path.join(currsim,currsto[0]), 'iterations')['string'][0])[-1]

            # Identify final objectives. Note: These objectives = w*cost
            obj = search_string_in_file(os.path.join(currsim,currsto[0]), 'objective')['string']        
            cols = []
            vals = []
            for item in obj.items():
                cols.append(re.split('=', item[1])[0])
                vals.append(float(re.split('=', item[1])[1]))          
            currobj = pd.DataFrame([vals], columns = cols)
            objectives = pd.concat([objectives, currobj])

            # Compile list of simulation attributes/outcomes
            simlist.append(currsim)
            converged.append(success)
            iterations.append(it)
            duration.append(dur)
            xinit.append(currstate['/jointset/BoxGround/Box_tx/value'][0])
            yinit.append(currstate['/jointset/BoxGround/Box_ty/value'][0])
            xfin.append(currstate['/jointset/BoxGround/Box_tx/value'].iloc[-1])
            yfin.append(currstate['/jointset/BoxGround/Box_ty/value'].iloc[-1])

        # Get Moco study
        currstd = [f for f in os.listdir(currsim) if 'study' in f]

        if len(currstd) !=1:
            print('Error: '+ sim + 'has {} study files'.format(len(currstd)))
            break
        else:
            # Read Moco study
            currstudy = osim.MocoStudy(os.path.join(currsim,currstd[0]))
            problem = currstudy.updProblem()
            phase = problem.getPhase()
            w = []
            goals = [re.split('objective_',x)[-1] for x in cols[1::]]

            for g in goals:
                if g == 'effort':
                    w.append(phase.getGoal(g).getWeight())
                else:
                    rxnweights = phase.getGoal(g).getPropertyByName('reaction_weights').getValueAsObject().getPropertyByName('objects').updValueAsObject(0).getPropertyByName('weight')
                    w.append(float(rxnweights.toString()))
            currweights = pd.DataFrame([w], columns = ['w_'+x for x in goals])
            weights = pd.concat([weights, currweights])

        # Calculate costs. Note: if weight = 0, cost is NaN 
        costs = pd.DataFrame()
        for ob in objectives:
            if ob=='objective':
                costs['cost_total'] = objectives[ob]/weights.sum(axis=1)
            else:
                currgoal = re.split('objective_',ob)[-1]
                currw = weights['w_'+currgoal]
                costs['cost_'+currgoal] = objectives[ob]/currw

    statekey = pd.DataFrame({'Simulation': simlist,
                       'Converged': converged,
                       'Duration (s)': duration,
                        'Iterations': iterations,
                       'Initial x': xinit,
                       'Initial y': yinit,
                       'Final x': xfin,
                       'Final y': yfin})
    weights = weights.reset_index(drop=True)
    objectives= objectives.reset_index(drop=True)
    costs= costs.reset_index(drop=True)
    key = pd.concat([statekey, objectives, weights, costs], axis=1)
    return key

def generateModelKey(modeldir,modelkey):
    allmodels = [] # Contains model path + name
    x = [] # Contains default x position of box
    y = [] # Contains default y position of box

    for modelfile in os.listdir(modeldir):
        currmodel = modeldir + '/' + modelfile
        model = osim.Model(currmodel)
        model.initSystem()

        # Items added to the key
        allmodels.append(currmodel)
        x.append(model.getCoordinateSet().get('Box_tx').getDefaultValue())
        y.append(model.getCoordinateSet().get('Box_ty').getDefaultValue())

    keydf = pd.DataFrame({'Model': allmodels,
                         'Box_tx_default': x,
                         'Box_ty_default': y})

    keydf.to_csv(modelkey,sep = '\t', index = False)
    print('Key printed to' + modelkey)
    
def grabModels(path, keypath, initsimkey, finmodelkey):
    initkey = pd.read_csv(initsimkey, delimiter='\t')
    finkey = pd.read_csv(finmodelkey, delimiter='\t')

    # Identify simulation with (closest to) average initial x and lowest final cost, and copy the associated model to the current directory
    meanx = initkey[initkey['Initial x'] == findNearest(initkey['Initial x'],np.mean(initkey['Initial x']))]
    lowestcost = meanx[meanx['cost_total']==min(meanx['cost_total'])]
    if len(lowestcost)>1:
        print('Multiple simulations had the lowest cost. Currently using the first.')
    
    lowestcost=lowestcost.iloc[0]
    src = lowestcost['OutModel']
    modelname = re.split('/', src)[-1]
    dst = path+modelname
    shutil.copyfile(src, dst)
    print('Saved copy of model selected as '+dst + ' for use')

    # Identify final model with average x and copy it to current directory
    meanfinx = finkey[np.round(finkey['Box_tx_default'],4)==np.round(np.mean(finkey['Box_tx_default']),4)].iloc[0]
    finsrc = meanfinx['Model']
    finmodelname = re.split('/', finsrc)[-1]
    findst = path+finmodelname
    shutil.copyfile(finsrc, findst)
    print('Saved copy of final model selected as '+findst + ' for use')
    return dst, findst

def simsWeightSearch(path, simdir, weights, modelfile, finmodelfile, randfile, boundsfile, speedbounds, bounds_noFV, t0, tf, effort=[], eff_name='effort', eff_divbydisp =True, eff_exp=3, joints = [], jrmeasure=['force-x', 'force-y', 'force-z', 'moment-x', 'moment-y', 'moment-z'], maxiter=2000, nmesh = 25, conv_tol = 1e-2, const_tol = 1e-2):
    i = 0
    mkoutdir(simdir) #If directory does not exist, make it
    for w in weights:

        # Define models.
        model = osim.Model(modelfile)
        model.initSystem()

        # Name the simulation
        simname = 'Sim_{}'.format(i)

        # If output directory does not exist, make it
        outpath = simdir + simname
        outpath = mkoutdir(outpath, usedate=False)

        # Create bounds files (contains joint boundaries and initial/final states). Initial/final states match model/finmodel defaults
        formatbounds(modelfile, finmodelfile, boundsfile, speedbounds)

        # Reads bounds file and converts degrees to radians if needed
        bounds = parsebounds(boundsfile, model) 

        # Define optimizer goals
        allgoals = []
        
        if effort==True:
            # MocoControlGoal: sum of the absolute value of the controls raised to a 
            # given exponent, integrated over the phase.
            effort_goal = osim.MocoControlGoal(eff_name)
            effort_goal.setDivideByDisplacement(eff_divbydisp)
            effort_goal.setExponent(eff_exp)
            effort_goal.setWeight(w[0])
            allgoals.append(effort_goal)

        # MocoJointReactionGoal: Minimize the sum of squares of specified reaction 
        # moment and force measures for a given joint, integrated over the phase. 
        k = 1
        for j in joints:
            for meas in jrmeasure:
                rxn_goal = osim.MocoJointReactionGoal()
                rxn_goal.setReactionMeasures([meas])
                jrmeasuretag = meas[0:3]+meas[-2:].replace('-','_')
                rxn_goal.setName(j + '_' + jrmeasuretag)
                rxn_goal.setJointPath('/jointset/'+j)
                rxn_goal.setWeight(meas, w[k])
                k=k+1
                allgoals.append(rxn_goal)
                     
        # Define the Moco study
        study = defstudy(model, bounds, bounds_noFV, t0, allgoals, tf)

        # If random guess does not exist, create it. Then, format the linearly-interpolated guess and define solver    
        if os.path.exists(randfile) == True:
            guess = outpath + '/'+ 'Guess.mot'
            formatguess(randfile, boundsfile, guess)
            solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)
        else:
            print('Random guess did not exist. Creating now')
            guess = 'Random'

            #Just using to generate random guess file
            solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)

            # With random file generated, now format guess and redefine solver
            guess = outpath + '/'+ 'Guess.mot'
            formatguess(randfile, boundsfile, guess)
            solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)

        i = i+1
        
        # Solve and write the solution
        if not os.path.isfile('{}/{}.sto'.format(outpath,simname)):
            study.printToXML('{}/{}_study.xml'.format(outpath,simname))
            solution = study.solve()
            try:
                    solution.write('{}/{}.sto'.format(outpath,simname))
            except: 
                    solution.unseal().write('{}/{}_notconverged.sto'.format(outpath,simname))
        else:
            print('Simulation already exists. Please rename, move, or delete simulation.')
#%% scaleModel            
def scaleModel(outdir, modelfile, setupfile, staticpath, massdict):
    mkoutdir(outdir)
    allmodels = []
    for subject in os.listdir(staticpath):
        
        subj = re.split('.trc',subject)[0] # Identifier for subject
        scaledmodel = subj+'.osim' # Name of subject's scaled model
        subjsetup = subj+'_settings.xml' # Contains settings for scale tool for current subject. Use to reproduce scaled model/ troubleshoot/ check settings if needed.
        
        # Create output folder for subject
        subjdir = outdir+'/'+subj + '/'
        mkoutdir(subjdir)
        
        # Move trc to output directory. For some reason, OpenSim refused to run the tool if I didn't do this
        shutil.copyfile(staticpath+'/'+subject, subjdir+subject)
        
        # Call to generic scaling setup file. Adjust as needed for subject
        scaleTool = osim.ScaleTool(setupfile) 
        scaleTool.setSubjectMass(massdict[subj]) # Subject mass
        
        # Define generic model maker. Define generic model to scale
        modelMaker = scaleTool.getGenericModelMaker()
        modelMaker.setModelFileName(modelfile)
        
        # Define model scaler
        modelScaler = scaleTool.getModelScaler()
        modelScaler.setOutputModelFileName(scaledmodel) # Scaled model file to create
        modelScaler.setMarkerFileName(subject) # Static trial used for scaling model
        
        # Save these settings to the subject's directory
        scaleTool.printToXML(subjdir+subjsetup)
        
        # Define model
        model = osim.Model(modelfile)
        state = model.initSystem()
    
        # Call to the setup file created. This is less computationally efficient (writing file and then reloading it), but ensures that the settings file output is indeed the one used to scale the model.
        scaleTool = osim.ScaleTool(subjdir+'/'+subjsetup)
    
        # Scale the model
        scaleTool.getModelScaler().processModel(model, subjdir)

        print('Finished scaling '+subj)
        allmodels.append(subjdir+scaledmodel)
    return allmodels
#%% setboxMass
def setboxMass(allmodels, boxmass):
    for modelfile in allmodels:
        model = osim.Model(modelfile)
        subj = re.split('/',modelfile)[-1]
        model.getBodySet().get('Box').setMass(boxmass)
        model.printToXML(modelfile)
        print('Set box mass of ' + subj+ ' to {} kg'.format(boxmass))
        
#%% adjustPosture
def adjustPosture(allmodels, modelfile_initpose):
    UEcoords = ['arm_add_r','arm_rot_r','pro_sup_r','wrist_dev_r']
    coords = {}

    # Get relevant coords (see matchcoords) from generic model and format as dictionary
    modelinit = osim.Model(modelfile_initpose)
    modelinit.initSystem()
    initcoords = modelinit.getCoordinateSet()
    iterator = initcoords.SetIterator(initcoords, 0)
    for item in iterator:
        currcoord = item.getName()   
        coords[currcoord]= modelinit.getCoordinateSet().get(currcoord).getDefaultValue()
        
    # Iterate through all models and adjust each
    for modelfile in allmodels:
        # Define model and initialize
        model = osim.Model(modelfile)
        state = model.initSystem()
        
        # Iterate through all coordinates. Get value for each coord for the coords defined. Then, set these values as the default.
        allcoords = model.getCoordinateSet()
        iterator = allcoords.SetIterator(allcoords, 0)
        for item in iterator:
            currcoord = item.getName()
            if currcoord in UEcoords:
                currval = 0
                model.getCoordinateSet().get(currcoord).set_is_free_to_satisfy_constraints(False)
            else:
                currval = coords[currcoord]
            model.getCoordinateSet().get(currcoord).setDefaultValue(currval)
        
        # Save model
        model.printToXML(modelfile)
    print('Adjusted model postures to roughly that of picking up the box')
#%% adjustBox
def adjustBox(allmodels):
    for modelfile in allmodels:
        # Define model and initialize
        model = osim.Model(modelfile)
        state = model.initSystem()
        
        # Get current Box_tx value and set it as default. Lock tz
        tz = model.getCoordinateSet().get('Box_tz').getValue(state)
        model.getCoordinateSet().get('Box_tz').setDefaultValue(tz)
        model.getCoordinateSet().get('Box_tz').setDefaultLocked(True)
        model.getCoordinateSet().get('Box_tz').set_is_free_to_satisfy_constraints(False)
    
        # Lock all box rotations
        model.getCoordinateSet().get('Box_rx').setDefaultLocked(True)
        model.getCoordinateSet().get('Box_ry').setDefaultLocked(True)
        model.getCoordinateSet().get('Box_rz').setDefaultLocked(True)
        
        # Adjust model default coordinates to be enforced. This helps to maintain model position while enabling constraint.
        allcoords = model.getCoordinateSet()
        iterator = allcoords.SetIterator(allcoords, 0)
        for item in iterator:
            if 'Box' not in item.getName():
                item.set_is_free_to_satisfy_constraints(False)
                
        # Adjust constraint. Make box align with center of mass of the hand
        handcom = model.getBodySet().get('hand_r').getMassCenter()[1] # COM is defined on proximal-distal axis of hand (zero on other axes). Therefore I only grabbed this indice
        boxcon = model.getConstraintSet().get('hand_r_box_con')
        boxcon.getComponent('box_offset').set_translation(osim.Vec3(handcom, -0.02,0)) # Positions box on COM of hand, with a 2 cm offset above it
        boxcon.set_isEnforced(True)
        
        # Adjust model default coordinates to not be enforced (as needed for adjust box positions in Step2)
        allcoords = model.getCoordinateSet()
        iterator = allcoords.SetIterator(allcoords, 0)
        for item in iterator:
            if 'Box' not in item.getName():
                item.set_is_free_to_satisfy_constraints(True)
        
        model.printToXML(modelfile)
    print('Adjusted box: enabled constraint, locked tz and all rots')

#%% calculateWeights
def calculateWeights(key, weightfile):
    costcols = [c for c in key if 'cost' in c]
    goalnames = []
    w = []
    for c in costcols:
        if '_total' not in c:
            currcost = key[c].dropna()
            goalnames.append(c.replace('cost_',''))
            w.append(currcost.values[0]/key['cost_total'].sum())
    weights = pd.DataFrame(data = [w], columns = goalnames)
    weights.to_csv(weightfile, sep='\t', index = False)
    print('Weights printed to '+weightfile)
    
    return weights
#%% runSims
def runSims(path, simdir, weights, modeldir, finalmodeldir, randfile, boundsfile, speedbounds, bounds_noFV, t0, tf, effort=[], eff_name='effort', eff_divbydisp =True, eff_exp=3, joints = [], jrmeasure=['force-x', 'force-y', 'force-z', 'moment-x', 'moment-y', 'moment-z'], maxiter=2000, nmesh = 25, conv_tol = 1e-2, const_tol = 1e-2):
    # Create simulation parent directory
    mkoutdir(simdir)
    
    # Get list of models to iterate through
    modelfiles = os.listdir(modeldir)
    finalmodelfiles = os.listdir(finalmodeldir)
    
    i=0
    for finmodelfile in finalmodelfiles:
        currfinmodel = finalmodeldir+finmodelfile
        
        for modelfile in modelfiles:
            currmodel = modeldir + modelfile
            model = osim.Model(currmodel)
            model.initSystem()
                
            # Name the simulation
            simname = 'Sim_{}'.format(i)
    
            # If output directory does not exist, make it
            outpath = simdir + simname
            outpath = mkoutdir(outpath)
    
            # Create bounds files (contains joint boundaries and initial/final states). Initial/final states match model/finmodel defaults
            formatbounds(currmodel, currfinmodel, boundsfile, speedbounds)
    
            # Reads bounds file and converts degrees to radians if needed
            bounds = parsebounds(boundsfile, model) 
    
            # Define optimizer goals
            allgoals = []
            
            if effort==True:
                # MocoControlGoal: sum of the absolute value of the controls raised to a 
                # given exponent, integrated over the phase.
                effort_goal = osim.MocoControlGoal(eff_name)
                effort_goal.setDivideByDisplacement(eff_divbydisp)
                effort_goal.setExponent(eff_exp)
                effort_goal.setWeight(weights['effort'].values[0])
                allgoals.append(effort_goal)
    
            # MocoJointReactionGoal: Minimize the sum of squares of specified reaction 
            # moment and force measures for a given joint, integrated over the phase. 
            for j in joints:
                for meas in jrmeasure:
                    rxn_goal = osim.MocoJointReactionGoal()
                    rxn_goal.setReactionMeasures([meas])
                    jrmeasuretag = meas[0:3]+meas[-2:].replace('-','_')
                    rxn_goal.setName(j + '_' + jrmeasuretag)
                    rxn_goal.setJointPath('/jointset/'+j)
                    rxn_goal.setWeight(meas, weights[j+'_'+jrmeasuretag].values[0])
                    allgoals.append(rxn_goal)
                         
            # Define the Moco study
            study = defstudy(model, bounds, bounds_noFV, t0, allgoals, tf)
    
            # If random guess does not exist, create it. Then, format the linearly-interpolated guess and define solver    
            if os.path.exists(randfile) == True:
                guess = outpath + '/'+ 'Guess.mot'
                formatguess(randfile, boundsfile, guess)
                solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)
            else:
                print('Random guess did not exist. Creating now')
                guess = 'Random'
    
                #Just using to generate random guess file
                solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)
    
                # With random file generated, now format guess and redefine solver
                guess = outpath + '/'+ 'Guess.mot'
                formatguess(randfile, boundsfile, guess)
                solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)
    
            i = i+1
            
            # Solve and write the solution
            if not os.path.isfile('{}/{}.sto'.format(outpath,simname)):
                if not os.path.isfile('{}/{}_notconverged.sto'.format(outpath,simname)):
                    study.printToXML('{}/{}_study.xml'.format(outpath,simname))
                    solution = study.solve()
                    try:
                            solution.write('{}/{}.sto'.format(outpath,simname))
                    except: 
                            solution.unseal().write('{}/{}_notconverged.sto'.format(outpath,simname))
                else:
                    print('Simulation already exists. Please rename, move, or delete simulation.')
                    
#%% rsWeights
def rsWeights(key, weightfile):
    weightcols = [x for x in key.columns if 'w_' in x]
    weights = key[key['cost_total']==min(key['cost_total'])][weightcols] # Select weights associated with simulation that had lowest final costs
    weights.columns = weights.columns.str.lstrip("w_")
    weights.to_csv(weightfile, sep='\t', index = False)
    print('Weights printed to '+weightfile)
    
#%% findNearest
# Source : https://www.codegrepper.com/code-examples/python/find+the+closest+value+in+an+array+python
def findNearest(array,value):
    array = np.asarray(array)
    idx = (np.abs(array-value)).argmin()
    return array[idx]
#%% formatData

def formatData(simpath, outpath, pospicklename, velpicklename, posedata = True):
    subjfolders = [simpath+x for x in next(os.walk(simpath))[1] if 'Output_Subject' in x]
    
    for subjfolder in subjfolders:
        badsims = 0
        subj = re.split('/',subjfolder)[-1]
        sims = os.listdir(subjfolder+'/Sims')
        random.shuffle(sims)
        posdata = pd.DataFrame()
        veldata = pd.DataFrame()
        
        for sim in sims:
            simdir = subjfolder+ '/Sims'+ '/' +sim +'/'
            currsto = [x for x in os.listdir(simdir) if sim+'.sto' in x]
            if len(currsto)!=1:
                #print(sim + ' has {} converged Moco outputs'.format(len(currsto)))
                badsims = badsims+1
                
                pass
            else:
                currsto = currsto[0]
                endheader = search_string_in_file(os.path.join(simdir,currsto), 'endheader')['line'][0]
                states = pd.read_csv(simdir+currsto, skiprows = endheader, sep = '\t')
                allcols = states.columns
                coordcols = [x for x in allcols if (('/value' in x) and ('Box' not in x))]
                boxcols = [x for x in allcols if (('Box_tx' in x) or ('Box_ty' in x))]
                
                if posedata ==True:
                    coordstates = states[coordcols]
                    coordstates.columns = [re.split('/',x)[-2] for x in coordstates.columns]
    
                boxstates = states[boxcols]
                boxstates.columns = [x.replace('/jointset/BoxGround/','') for x in boxstates.columns]
                
                tlen = len(states['time'])
                        
                boxpose = pd.DataFrame({'time' : states['time'],
                                        'txinit': boxstates['Box_tx/value'].iloc[0].repeat(tlen),
                                        'txfin': boxstates['Box_tx/value'].iloc[-1].repeat(tlen),
                                        'Box_tx': boxstates['Box_tx/value'],
                                        'Box_ty': boxstates['Box_ty/value']})
                
                if posedata ==True:
                    initpose = pd.DataFrame()
                    for col in coordstates.columns:
                        initpose[col] = coordstates[col].iloc[0].repeat(tlen)
                    currpose = pd.concat([boxpose, initpose], axis =1)
                else: 
                    print('Initial pose will not be saved to output data files')
                    currpose = boxpose
                posdata = pd.concat([posdata, currpose], ignore_index=True)
                
                currboxvel = pd.DataFrame({'Box_tx' : boxstates['Box_tx/value'],
                                        'Box_ty' : boxstates['Box_ty/value'],
                                        'txinit': boxstates['Box_tx/value'].iloc[0].repeat(tlen),
                                        'txfin': boxstates['Box_tx/value'].iloc[-1].repeat(tlen),
                                        'Box_vx' : boxstates['Box_tx/speed'],
                                        'Box_vy' : boxstates['Box_ty/speed']})
                if posedata ==True:
                    currvel = pd.concat([currboxvel, initpose], axis =1)
                else:
                    currvel = currboxvel
                veldata = pd.concat([veldata, currvel],ignore_index=True)
        
        outfile = outpath+ '/'+subj+ '_'+pospicklename
        posdata.to_pickle(outfile)
        posdata = pd.read_pickle(outfile)  # Check that data can be read
        
        outfile = outpath+ '/'+subj+ '_'+velpicklename
        veldata.to_pickle(outfile)
        veldata = pd.read_pickle(outfile)  # Check that data can be read
        print('{}/{} sims were excluded from output files for '.format(badsims, len(sims))+subj+ '\n')
    print('Sims excluded from output file either (1) failed to converge (2) did not have any simulation output at all or (3) had more than one output file.')
#%% dataSplit
def dataSplit(file, features, outputs, test_size = 0.2, shuffle = False):
    data = pd.read_pickle(file)
    if len(features)==0:
        print('All data columns except for outputs specified will be used as features. If this is unintended, please define features. \n')
        X = data.drop(outputs, axis = 1)
    else:
        X = data[features]
        
    y = data[outputs]

    # Train and test sets. Data was shuffled before pickling
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size= test_size, shuffle = shuffle)
    
    return X_train, X_test, y_train, y_test

#%% obpredplot
def add_subplot_axes(ax,rect,axisbg='w'):
    # Purpose: to be used with obpredplot to generate the histogram inset on the parity plot
    fig = plt.gcf()
    box = ax.get_position()
    width = box.width
    height = box.height
    inax_position  = ax.transAxes.transform(rect[0:2])
    transFigure = fig.transFigure.inverted()
    infig_position = transFigure.transform(inax_position)
    x = infig_position[0]
    y = infig_position[1]
    width *= rect[2]
    height *= rect[3]  
    subax = fig.add_axes([x,y,width,height])
    x_labelsize = subax.get_xticklabels()[0].get_size()
    y_labelsize = subax.get_yticklabels()[0].get_size()
    x_labelsize *= rect[2]**0.5
    y_labelsize *= rect[3]**0.5
    subax.xaxis.set_tick_params(labelsize=x_labelsize)
    subax.yaxis.set_tick_params(labelsize=y_labelsize)
    return subax

def obpredplot(observed, predicted, title, plotfile, units, ylab='Predicted', xlab = 'observed'):
    # generates a parity plot given some data
    mae = np.mean(np.abs(observed-predicted))
    max_error = np.max(np.abs(observed-predicted))
    rmse = np.sqrt(np.sum(np.array(observed - predicted)**2)/len(observed))
    fig, ax = plt.subplots(dpi=600)

    fig = sns.kdeplot(x=observed,
        y=predicted,
        shade=True,
        #cbar=True,
        palette=sns.color_palette('Blues'))
        #thresh=0.02,
        #fill=True)
    
    ax.plot(observed, predicted,'b.', alpha=0.4, markersize=0.5)
    plt.ylim([min(observed),max(observed)])
    plt.xlim([min(observed),max(observed)])
    plt.title(title)
    ax.plot(predicted, predicted,'--k', linewidth=0.5)
    ax.set_ylabel(ylab)
    ax.set_xlabel(xlab)
    ax.text(0.1, 0.90,'MAE: '+str(round(mae,3)) + ' ' +units, ha='left', va='center', transform=ax.transAxes)
    ax.text(0.1, 0.85,'RMSE: '+str(round(rmse,3)) + ' ' +units, ha='left', va='center', transform=ax.transAxes)
    ax.text(0.1, 0.80,'Max Error: '+str(round(max_error,3))+ ' ' +units, ha='left', va='center', transform=ax.transAxes)
    subpos = [0.7,0.2,0.3,0.3]
    rect = [0.2,0.2,0.7,0.7]
    subax = add_subplot_axes(ax,subpos,axisbg='w')
    subax.hist((observed-predicted),bins=50)
    plt.yscale('log')
    subax.set_xlabel('Absolute Error ({})'.format(units))
    subax.set_ylabel('Count')
    plt.tight_layout()
    plt.savefig(plotfile, dpi = 600)
    return 
#%% genKNN
# KNN tuning, training, testing. Outputs 
def genKNN(files, features, outputs, outputunits, modelnames, subjects, path, hyperparameters, cv=5, n_iter=10):
    modeldefs = pd.DataFrame({'datafiles': files,
                              'features': features,
                              'outputs': outputs,
                              'outputunits':outputunits,
                              'modelname': modelnames,
                              'subject': subjects})
    
    figdir = path+'Output_KNN'
    mkoutdir(figdir)
    leaf_size = []
    n_neighbors = []
    p = []
    CoD = []
    for index, row in modeldefs.iterrows():
        file = row['datafiles']
        features = row['features']
        outputs = row['outputs']
        outputunits = row['outputunits']
        modelname = row['modelname']
        subject = row['subject']
        
        # Each subject's model and figures are stored in it's own folder, created here
        subjdir = figdir+'/'+subject
        mkoutdir(subjdir) 
        os.chdir(subjdir)
        
        # Split up data as needed for machine learning
        [X_train, X_test, y_train, y_test] = dataSplit(file, features, outputs)
    
        # Define KNN object
        knn =  KNeighborsRegressor()
    
        # Employ random search
        clf = RandomizedSearchCV(knn, hyperparameters, cv=cv, n_iter=n_iter)
    
        #% Fit model and evaluate performance
        # Fit the model
        clf = clf.fit(X_train, y_train)
        params = clf.best_params_
        best_knn = knn.set_params(**params).fit(X_train, y_train)
    
        # Save best hyperparameters identified and corresponding model performance
        leaf_size.append(best_knn.get_params()['leaf_size'])
        n_neighbors.append(best_knn.get_params()['n_neighbors'])
        p.append(best_knn.get_params()['p'])
        CoD.append(best_knn.score(X_test, y_test)) # Coefficient of determination when predicting on test data using tuned parameters
        
        # Create parity plots to compare KNN predictions with original simulation data
        for i in range(len(outputs)):
            xpredicted = best_knn.predict(X_test)[:,i]
            xobserved = y_test.iloc[:,i].values
            title = 'KNN Prediction of {} on Test Data'.format(outputs[i])
            plotfile = subjdir+'/'+title+'.png'
            obpredplot(xobserved, xpredicted, title, plotfile, units = outputunits[i], xlab = 'Simulated {} ({})'.format(outputs[i], outputunits[i]),ylab = 'KNN-Predicted {} ({})'.format(outputs[i],outputunits[i]))
            plt.close()
        
        
        # save the model
        joblib.dump(best_knn, modelname+'.sav')
        print(modelname+' was saved for ' + subject)
    
        # load the model (checking that it saved as intended)
        loaded_knn = joblib.load(modelname+'.sav')
    
        # save the random search
        filename = modelname+'_randomsearch.sav'
        joblib.dump(clf, filename)

#%% genSurrogateModel
# Currently there are three "modeltype" options: k nearest neighbors, random forests, and support vector regression
def genSurrogateModel(modeltype, files, features, outputs, outputunits, modelnames, subjects, path, hyperparameters, cv=5, n_iter=10):
    modeldefs = pd.DataFrame({'datafiles': files,
                              'features': features,
                              'outputs': outputs,
                              'outputunits':outputunits,
                              'modelname': modelnames,
                              'subject': subjects})
    
    figdir = path+'Output_'+modeltype
    mkoutdir(figdir)
    for index, row in modeldefs.iterrows():
        file = row['datafiles']
        features = row['features']
        outputs = row['outputs']
        outputunits = row['outputunits']
        modelname = row['modelname']
        subject = row['subject']
        
        # Each subject's model and figures are stored in it's own folder, created here
        subjdir = figdir+'/'+subject
        mkoutdir(subjdir) 
        os.chdir(subjdir)
        
        # Split up data as needed for machine learning
        [X_train, X_test, y_train, y_test] = dataSplit(file, features, outputs)
    
        # Define model object
        if modeltype== 'KNNReg':
            if len(outputs)>1:
                model= MultiOutputRegressor(KNeighborsRegressor())
            else:                 
                model= KNeighborsRegressor()
        if modeltype=='RFReg':
            if len(outputs)>1:    
                model =  MultiOutputRegressor(RandomForestRegressor())
            else:                 
                model= RandomForestRegressor()
        if modeltype=='SVReg':
            if len(outputs)>1:
                model =  MultiOutputRegressor(SVR())
            else:
                model = SVR()
            
        # Employ random search
        clf = RandomizedSearchCV(model, hyperparameters, cv=cv, n_iter=n_iter)
    
        #% Fit model and evaluate performance
        # Fit the model
        clf = clf.fit(X_train, y_train)
        params = clf.best_params_
        best_model    = model.set_params(**params).fit(X_train, y_train)
    
        # Create parity plots to compare model predictions with original simulation data
        for i in range(len(outputs)):
            xpredicted = best_model.predict(X_test)[:,i]
            xobserved = y_test.iloc[:,i].values
            title = modeltype+' Prediction of {} on Test Data'.format(outputs[i])
            plotfile = subjdir+'/'+title+'.png'
            obpredplot(xobserved, xpredicted, title, plotfile, units = outputunits[i], xlab = 'Simulated {} ({})'.format(outputs[i], outputunits[i]),ylab = modeltype+'-Predicted {} ({})'.format(outputs[i],outputunits[i]))
            plt.close()
        
        
        # save the model
        modelfile = subjdir+'/'+modelname+'.sav'
        joblib.dump(best_model, modelfile)
        print(modeltype+' '+modelname+' was saved for ' + subject)
    
        # load the model (checking that it saved as intended)
        loaded_model = joblib.load(modelfile)
        
        # save the random search
        searchfile = subjdir+'/'+modelname+'_randomsearch.sav'
        joblib.dump(clf, searchfile)
        
#%% getListOfFiles
# For the given path, get the List of all files in the directory tree 
# I am not the original author of this function. Source:
# https://thispointer.com/python-how-to-get-list-of-files-in-directory-and-sub-directories/

def getListOfFiles(dirName):
    # create a list of file and sub directories 
    # names in the given directory 
    listOfFile = os.listdir(dirName)
    allFiles = list()
    # Iterate over all the entries
    for entry in listOfFile:
        # Create full path
        fullPath = os.path.join(dirName, entry)
        # If entry is a directory then get the list of files in this directory 
        if os.path.isdir(fullPath):
            allFiles = allFiles + getListOfFiles(fullPath)
        else:
            allFiles.append(fullPath)

    return allFiles