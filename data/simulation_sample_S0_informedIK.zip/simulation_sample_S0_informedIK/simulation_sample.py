'''
The code below is used to run a sample simulation of bimanual lift using 
OpenSim Moco.

'''
#%% Import packages and define functions
import opensim as osim
import os

path = 'D:/KalynK/HRI/2023_Bioengineering/simulation_sample_S0_informedIK'
os.chdir(path)
from customfuncs import *

#%% Simulation inputs

modeldir = path + '/InitModels/'
finalmodeldir = path+ '/FinalModels/'
speedbounds = path+ '/speedbounds.txt' # Contains speed bounds only
randfile = path+ '/RandomGuess.mot' # Random guess
simdir = path+'/Simulations/'

# Time bound range
[t0, tf] = [0, 2.44]

# Solver inputs
maxiter=3000
nmesh = 25
conv_tol = 1e-2
const_tol = 1e-2

# Define joint reaction goals
joints = ['back', 'hip_r', 'knee_r','ankle_r']
jrmeasure = ['moment-z']

# List of coordinates for which no final value should be set
bounds_noFV = []
bounds_noFV_names_extra = ['/knee_r/knee_angle_r/','/back/lumbar_extension/','/ankle_r/ankle_angle_r/','/hip_r/hip_flexion_r/', '/acromial_r/arm_flex_r/', '/acromial_r/arm_add_r/', '/acromial_r/arm_rot_r/', '/elbow_r/elbow_flex_r/', '/radioulnar_r/pro_sup_r/', '/radius_hand_r/wrist_flex_r/', '/radius_hand_r/wrist_dev_r/' ]
leftcoords = []
for r in bounds_noFV_names_extra:
    leftcoords.append(r.replace('_r/','_l/'))
    
bounds_noFV_names = ['/BoxGround/Box_rx/', '/BoxGround/Box_ry/', '/BoxGround/Box_rz/', '/BoxGround/Box_tz/', '/acromial_r/arm_flex_r/', '/acromial_r/arm_add_r/', '/acromial_r/arm_rot_r/', '/elbow_r/elbow_flex_r/', '/radioulnar_r/pro_sup_r/', '/radius_hand_r/wrist_flex_r/', '/radius_hand_r/wrist_dev_r/' ]

# For now, these weights were grabbed from Sim_0 in MocoSims_FINAL_0425<Simulations_WeightSearch
# This sim had converged on half model
weight_dict = {'effort': 0.22911379948063601,
               'back': 0.30463011135454088,
               'hip_r':0.010660825989450545,
               'knee_r':0.36738604839461803,
               'ankle_r': 0.088209214780754511}

bounds_noFV_names = bounds_noFV_names + bounds_noFV_names_extra + leftcoords
for coord in bounds_noFV_names:
    bounds_noFV.append('/jointset' + coord + 'value') 
    
#%%

# Get list of models to iterate through
modelfiles = os.listdir(modeldir)
finalmodelfiles = os.listdir(finalmodeldir)

# Record final and initial box values for key
tyfin = []
txinit = []
tyinit = []
simkey = [] 
i = 0

for model_final in finalmodelfiles:
    currfinmodel = finalmodeldir+model_final
    finalmodel = osim.Model(currfinmodel)
    for modelfile in modelfiles:
        currmodel = modeldir + modelfile
        model = osim.Model(currmodel)
        model.initSystem()
        
        simname = 'Sim_{}'.format(i)

        # If output directory does not exist, make it
        outpath = simdir + simname
        outpath = mkoutdir(outpath, usedate=False)
        print(outpath)
        
        # Create bounds files
        boundsfile = outpath + '/'+ 'allbounds.txt'
        formatbounds(currmodel, currfinmodel, boundsfile, speedbounds)
        
        # Reads bounds file and converts degrees to radians if needed
        bounds = parsebounds(boundsfile, model) 
        
        # Define optimizer goals
        allgoals = []
        
        # MocoControlGoal: sum of the absolute value of the controls raised to a 
        # given exponent, integrated over the phase.
        effort_goal = osim.MocoControlGoal('effort')
        effort_goal.setDivideByDisplacement(True)
        effort_goal.setExponent(3)
        effort_goal.setWeight(weight_dict['effort'])
        allgoals.append(effort_goal)
        
        # MocoJointReactionGoal: Minimize the sum of squares of specified reaction 
        # moment and force measures for a given joint, integrated over the phase. 
        for j in joints:    
            rxn_goal = osim.MocoJointReactionGoal()
            rxn_goal.setName(j + '_' + 'moment_z')
            rxn_goal.setReactionMeasures(['moment-z'])
            rxn_goal.setJointPath('/jointset/'+j)
            rxn_goal.setWeight('moment-z', weight_dict[j])
            allgoals.append(rxn_goal)
        
        # Define the Moco study
        study = defstudy(model, bounds, bounds_noFV, t0, allgoals, tf, tfhigh = [])
        
        # If random guess does not exist, create it. Then, format the linearly-interpolated guess and define solver    
        if os.path.exists(randfile) == True:
            guess = outpath + '/'+ 'Guess.mot'
            formatguess(randfile, boundsfile, guess)
            solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)
        else:
            print('Random guess did not exist. Creating now')
            guess = 'Random'
            
            #Just using to generate random guess file
            solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)
            
            # With random file generated, now format guess and redefine solver
            guess = outpath + '/'+ 'Guess.mot'
            formatguess(randfile, boundsfile, guess)
            solver = defsolver(study, path, guess = guess, maxiter=maxiter, nmesh = nmesh, conv_tol = conv_tol, const_tol = const_tol)
        
        i = i+1
        
        # Solve and write the solution
        if not os.path.isfile('{}/{}.sto'.format(outpath,simname)):
            study.printToXML('{}/{}_study.xml'.format(outpath,simname))
            solution = study.solve()
            try:
                solution.write('{}/{}.sto'.format(outpath,simname))
            except: 
                solution.unseal().write('{}/{}_notconverged.sto'.format(outpath,simname))
        else:
            print('Simulation already exists. Please rename, move, or delete simulation.')
            
        


# %%
